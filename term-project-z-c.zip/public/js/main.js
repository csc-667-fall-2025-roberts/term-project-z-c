const t=document.querySelector("#test-button");t?.addEventListener("click",e=>{e.preventDefault(),setTimeout(()=>{alert("you clicked around 1 seconds ago")},1e3)});
//# sourceMappingURL=main.js.map
